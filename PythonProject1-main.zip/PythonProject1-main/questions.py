quiz = {
    1 : {
        "question" : "Who is the father of Computer science?",
        "answer" : "Charles Babbage"
    },
    2 : {
        "question" : "In a computer, most processing takes place in ___?",
        "answer" : "CPU"
    },
    3 : {
        "question" : "In which type of computer, data are represented as discrete signals?",
        "answer" : "Digital Computer"
    },
    4 : {
        "question" : "Scientific Name of Computer?",
        "answer" : "Sillico sapiens"
    },
    5 : {
        "question" : "What is the name of the display feature that highlights are of the screen which requires operator attention?",
        "answer" : "Reverse video"
    },
   6 : {
        "question" : "Computers, combine both measuring and counting, are called ___?",
        "answer" : "Hybrid Computer"
    },
    7 :{
        "question" : "What is FORTRAN?",
        "answer" : "Formula Translation"
    },
    8 :{
        "question" : "What translates and executes program at run time line by line?",
        "answer" : "Interpreter"
    },
    9 :{
        "question" : "What converts an entire program into machine language?",
        "answer" : "Compiler"
    },
    10 :{
        "question" : "Who is the father of personal computer?	?",
        "answer" : "Edward Robert"
    },
    11:{
        "question" : "EEPROM stands for ___?",
        "answer" : "Electronic Erasable Programmable Read Only Memory"
    },
    12 :{
        "question" : "Who developed the first electronic computer?",
        "answer" : "J.V. Atansoff"
    },
    13 :{
        "question" : "Which programming languages are classified as low level languages?",
        "answer" : "Assembly Language"
    },
    14 :{
        "question" : "The first web browser is ___?	",
        "answer" : "Mosaic"
    },
    15 :{
        "question" : "First page of Website is termed as ___?",
        "answer" : "Homepage"
    },
    16 :{
        "question" : "IBM stands for ___?",
        "answer" : "International Business Machines"
    },
    17 :{
        "question" : "Office LANs, which are scattered geographically on large scale, can be connected by the use of corporate ___?",
        "answer" : "WAN ( wide area network )",
    },
    18 :{
        "question" : "MICR stands for ___?",
        "answer" : "Magnetic Ink Character Recognition"
    },
    19 :{
        "question" : "Name of 1st electronic computer?",
        "answer" : "ENIAC"
    },
    20 :{
        "question" : "No. of different characters in ASCII coding system?",
        "answer" : "1024"
    }
}